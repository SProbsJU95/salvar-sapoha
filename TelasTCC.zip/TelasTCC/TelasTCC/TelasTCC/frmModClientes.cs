﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Cliente;
using TelasTCC.DB.Endereco;

namespace TelasTCC
{
    public partial class frmModClientes : Form
    {
        public frmModClientes()
        {
            InitializeComponent();
            ListarDgv();
        }

        
        
        private void ListarDgv()
        {
            ClienteBusiness business = new ClienteBusiness();
            List<ClienteDTO> lista = business.Listar();

            dgvClientes.AutoGenerateColumns = false;
            dgvClientes.DataSource = lista;
        }
        
        private void btnCadCliente_Click(object sender, EventArgs e)
        {
            Form cadClientes = new frmCadCliente();
            cadClientes.Show();

            ListarDgv();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            // cliente
            ClienteDTO dto = new ClienteDTO();
            dto.Nome = txtNome.Text;
            dto.Telefone = txtTelefone.Text;

            ClienteBusiness business = new ClienteBusiness();
            business.AtualizarCliente(dto, lblTelefone.Text);

            // endereco
            EnderecoDTO dtoe = new EnderecoDTO();
            dtoe.Bairro = txtBairro.Text;
            dtoe.Rua = txtRua.Text;
            dtoe.Cep = txtCep.Text;
            dtoe.Numero = txtNumero.Text;
            dtoe.IdEndereco = lblIdEndereco.Text;

            EnderecoBusiness businessE = new EnderecoBusiness();
            businessE.AtualizarEnderecoCliente(dtoe);

            this.Width = 535;

            ListarDgv();
        }

        private void btnClientesCadastrados_Click(object sender, EventArgs e)
        {
            ClienteDatabase databse = new ClienteDatabase();
            lblRua.Text = databse.ListarInfo("rua", this.dgvClientes.CurrentRow.Cells[0].Value.ToString());
            lblNumero.Text = databse.ListarInfo("numero", this.dgvClientes.CurrentRow.Cells[0].Value.ToString());
            lblCep.Text = databse.ListarInfo("cep", this.dgvClientes.CurrentRow.Cells[0].Value.ToString());
            lblBairro.Text = databse.ListarInfo("Bairro", this.dgvClientes.CurrentRow.Cells[0].Value.ToString());
            lblIdEndereco.Text = this.dgvClientes.CurrentRow.Cells[0].Value.ToString();
            lblNome.Text = this.dgvClientes.CurrentRow.Cells[1].Value.ToString();
            lblTelefone.Text = this.dgvClientes.CurrentRow.Cells[2].Value.ToString();

            this.Width = 953;

            ListarLabel();
        }

        public void ListarLabel()
        {
            txtRua.Text = lblRua.Text;
            txtNumero.Text = lblNumero.Text;
            txtCep.Text = lblCep.Text;
            txtBairro.Text = lblBairro.Text;

            txtNome.Text = lblNome.Text;
            txtTelefone.Text = lblTelefone.Text;
        }
    }
}