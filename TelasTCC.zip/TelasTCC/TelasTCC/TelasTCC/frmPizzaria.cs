﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Pizzaria;

namespace TelasTCC
{
    public partial class frmPizzaria : Form
    {
        public frmPizzaria()
        {
            InitializeComponent();
            cbSabor_dois.Enabled = false;
        }

        static int entregaSalao = 0;
        public void setEntregaSalao(int entreSalao) { entregaSalao = entreSalao; }

        private void btnEnviarBebidas_Click(object sender, EventArgs e)
        {
            PizzariaDTO dto = new PizzariaDTO();
            if (cbDose.Text != string.Empty) { dto.Produto = cbDose.Text; }
            if (cbLata.Text != string.Empty) { dto.Produto = cbLata.Text; }
            if (cbSuco.Text != string.Empty) { dto.Produto = cbSuco.Text; }
            if (cb600ml.Text != string.Empty) { dto.Produto = cb600ml.Text; }
            if (cb2l.Text != string.Empty) { dto.Produto = cb2l.Text; }

            if (txtBebidadaQtde.Text != string.Empty) { dto.QuantidadeProduto = txtBebidadaQtde.Text; }
            else { dto.QuantidadeProduto = "1"; }

            PizzariaDatabase database = new PizzariaDatabase();
            dto.IdProduto = database.ListarProduto("idProduto",dto.Produto);

            dto.Preco = database.ListarProduto("valor",dto.Produto);

            dto.idPedido = database.ListarPedido();

            PizzariaBusiness business = new PizzariaBusiness();
            business.Salvar(dto);
            MessageBox.Show("Bebida cadastrada.");
        }

        private void btnEnviarSobremesa_Click(object sender, EventArgs e)
        {
            PizzariaDTO dto = new PizzariaDTO();
            if (cbSorvete.Text != string.Empty) { dto.Produto = cbSorvete.Text; }
            if (cbDoce.Text != string.Empty) { dto.Produto = cbDoce.Text; }

            if (txtSobremesaQtde.Text != string.Empty) { dto.QuantidadeProduto = txtSobremesaQtde.Text; }
            else { dto.QuantidadeProduto = "1"; }

            PizzariaDatabase database = new PizzariaDatabase();
            dto.IdProduto = database.ListarProduto("idProduto",dto.Produto);

            dto.Preco = database.ListarProduto("valor",dto.Produto);

            dto.idPedido = database.ListarPedido();

            PizzariaBusiness business = new PizzariaBusiness();
            business.Salvar(dto);
            MessageBox.Show("Sobremesa cadastrada.");
        }
        
        private void btnEnviarPizza_Click(object sender, EventArgs e)
        {
            if (radInteira.Checked == true)
            {
                PizzariaDTO dto = new PizzariaDTO();
                if (cbSabor_um.Text != string.Empty) { dto.Produto = cbSabor_um.Text; }

                if (txtPizzaBrotoEsfirraQtde.Text == string.Empty) { dto.QuantidadeProduto = "1"; }
                else { dto.QuantidadeProduto = txtPizzaBrotoEsfirraQtde.Text; }

                PizzariaDatabase database = new PizzariaDatabase();
                dto.IdProduto = database.ListarProduto("idProduto", dto.Produto);

                dto.Preco = database.ListarProduto("valor",dto.Produto);

                dto.idPedido = database.ListarPedido();

                PizzariaBusiness business = new PizzariaBusiness();
                business.Salvar(dto);
                MessageBox.Show("Refeição cadastrada.");
            }
            else if (radMeia.Checked == true)
            {
                PizzariaDTO dto = new PizzariaDTO();
                dto.Produto = cbSabor_um.Text;

                if (txtPizzaBrotoEsfirraQtde.Text == string.Empty) { dto.QuantidadeProduto = "1"; }
                else { dto.QuantidadeProduto = txtPizzaBrotoEsfirraQtde.Text; }

                PizzariaDatabase database = new PizzariaDatabase();
                dto.IdProduto = database.ListarProduto("idProduto",dto.Produto);

                string preco_um = database.ListarProduto("valor", dto.Produto);
                dto.Preco = "00.00";
                dto.idPedido = database.ListarPedido();

                dto.IdMeia = database.ListarMeia();//
                
                PizzariaBusiness business = new PizzariaBusiness();
                business.SalvarMeia(dto);
                
                //meia

                dto.Produto = cbSabor_dois.Text;
                dto.IdProduto = database.ListarProduto("idProduto",dto.Produto);

                string preco_dois = database.ListarProduto("valor", dto.Produto);
                if (float.Parse(preco_um)>float.Parse(preco_dois))
                {
                    dto.Preco = preco_um;
                }
                else if (float.Parse(preco_um)<float.Parse(preco_dois))
                {
                    dto.Preco = preco_dois;
                } 

                dto.idPedido = database.ListarPedido();

                business = new PizzariaBusiness();
                business.SalvarMeia(dto);

                MessageBox.Show("Refeição meia cadastrada.");
            }
        }

        private void ListarPizzaBroto(string pizzaBroto)
        {
            PizzariaBusiness business = new PizzariaBusiness();

            cbSabor_um.DisplayMember = "nome";
            cbSabor_dois.DisplayMember = "nome";

            int i = 0;
            while (i != 2)
            {
                if (i == 0) { DataTable lista = business.Listar(pizzaBroto); cbSabor_um.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar(pizzaBroto); cbSabor_dois.DataSource = lista; }
                i = 2;
            }
        }

        private void btnEnviarTudo_Click(object sender, EventArgs e)
        {
            PizzariaDTO dto = new PizzariaDTO();
            PizzariaDatabase database = new PizzariaDatabase();

            dto.idPedido = database.ListarPedido();
            dto.ValorFinal = database.ListarValorFinal(dto.idPedido);
            dto.TipoPedido = entregaSalao.ToString();
            
            PizzariaBusiness business = new PizzariaBusiness();
            business.SalvarPedido(dto);

            MessageBox.Show("Venda Finalizada!");

            Form finalizar = new frmFinalizarCompra();
            finalizar.Show();

            this.Close();
        }

        private void radPizza_CheckedChanged(object sender, EventArgs e)
        {
            ListarPizzaBroto("Pizza");
        }

        private void radEsfirra_CheckedChanged(object sender, EventArgs e)
        {
            ListarPizzaBroto("Esfirra");
        }

        private void radBroto_CheckedChanged(object sender, EventArgs e)
        {
            ListarPizzaBroto("Broto");
        }
        
        private void radMeia_CheckedChanged(object sender, EventArgs e)
        {
            if (radMeia.Checked == true){cbSabor_dois.Enabled = true;}
            else{cbSabor_dois.Enabled = false;}
        }
        
        private void cbDose_Click(object sender, EventArgs e)
        { 
            PizzariaBusiness business = new PizzariaBusiness();
            cbDose.DisplayMember = "nome";
            DataTable lista = business.Listar("Dose"); cbDose.DataSource = lista;

            //cbDose.DataSource = null;
            cbSuco.DataSource = null;
            cbLata.DataSource = null;
            cb600ml.DataSource = null;
            cb2l.DataSource = null;  
        }

        private void cbSuco_Click(object sender, EventArgs e)
        {
            PizzariaBusiness business = new PizzariaBusiness();
            cbSuco.DisplayMember = "nome";
            DataTable lista = business.Listar("Suco"); cbSuco.DataSource = lista;

            cbDose.DataSource = null;
            cbDose.DataSource = null;
            //cbSuco.DataSource = null;
            cbLata.DataSource = null;
            cb600ml.DataSource = null;
            cb2l.DataSource = null;
        }

        private void cbLata_Click(object sender, EventArgs e)
        {
            PizzariaBusiness business = new PizzariaBusiness();
            cbLata.DisplayMember = "nome";
            DataTable lista = business.Listar("Lata"); cbLata.DataSource = lista;

            cbDose.DataSource = null;
            cbDose.DataSource = null;
            cbSuco.DataSource = null;
            //cbLata.DataSource = null;
            cb600ml.DataSource = null;
            cb2l.DataSource = null;
        }

        private void cb600ml_Click(object sender, EventArgs e)
        {
            PizzariaBusiness business = new PizzariaBusiness();
            cb600ml.DisplayMember = "nome";
            DataTable lista = business.Listar("600ml"); cb600ml.DataSource = lista;

            cbDose.DataSource = null;
            cbDose.DataSource = null;
            cbSuco.DataSource = null;
            cbLata.DataSource = null;
            //cb600ml.DataSource = null;
            cb2l.DataSource = null;
        }

        private void cb2l_Click(object sender, EventArgs e)
        {
            PizzariaBusiness business = new PizzariaBusiness();
            cb2l.DisplayMember = "nome";
            DataTable lista = business.Listar("2l"); cb2l.DataSource = lista;

            cbDose.DataSource = null;
            cbDose.DataSource = null;
            cbSuco.DataSource = null;
            cbLata.DataSource = null;
            cb600ml.DataSource = null;
            //cb2l.DataSource = null;
        }

        private void cbSorvete_Click(object sender, EventArgs e)
        {
            PizzariaBusiness business = new PizzariaBusiness();
            cbSorvete.DisplayMember = "nome";

            DataTable lista = business.Listar("Sorvete"); cbSorvete.DataSource = lista;

            cbDoce.DataSource = null;
            //cbSorvete.DataSource = null;
        }

        private void cbDoce_Click(object sender, EventArgs e)
        {
            PizzariaBusiness business = new PizzariaBusiness();
            cbDoce.DisplayMember = "nome";

            DataTable lista = business.Listar("Doce"); cbDoce.DataSource = lista;

            //cbDoce.DataSource = null;
            cbSorvete.DataSource = null;
        }
    }
}
