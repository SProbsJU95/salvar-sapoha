﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Fornecedores;

namespace TelasTCC
{
    public partial class frmModFornecedores : Form
    {
        public frmModFornecedores()
        {
            InitializeComponent();
            Listar();
        }

        public void Listar()
        { 
            FornecedoresBusiness business = new FornecedoresBusiness();
            List<FornecedoresDTO> lista = business.Listar();

            dgvFornecedores.AutoGenerateColumns = false;
            dgvFornecedores.DataSource = lista;
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            frmCadFornecedor cadastro = new frmCadFornecedor();
            cadastro.Show();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            lblCnpj.Text = this.dgvFornecedores.CurrentRow.Cells[0].Value.ToString();
            lblNome.Text = this.dgvFornecedores.CurrentRow.Cells[2].Value.ToString();

            FornecedoresDatabase database = new FornecedoresDatabase();
            lblFornecimento.Text = database.ListarInfo("fornecimento", lblCnpj.Text);
            lblTelefone.Text = database.ListarInfo("telefone_um",lblCnpj.Text);
            lblTipoProduto.Text = database.ListarInfo("tipo_produto", lblCnpj.Text);
            lblTelefoneDois.Text = database.ListarInfo("telefone_dois", lblCnpj.Text);
            ListarEmTextBox();
        }
        
        public void ListarEmTextBox()
        {
            txtNome.Text = lblNome.Text;
            txtCnpj.Text = lblCnpj.Text;
            txtFornecimento.Text = lblFornecimento.Text;
            txtTelefone.Text = lblTelefone.Text;
            txtTelefoneDois.Text = lblTelefoneDois.Text;
            txtTipoFornecimento.Text = lblTipoProduto.Text;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apagar " + this.dgvFornecedores.CurrentRow.Cells[2].Value.ToString(), "Apagar fornecedor", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                FornecedoresDTO dto = new FornecedoresDTO();
                dto.Cnpj = this.dgvFornecedores.CurrentRow.Cells[0].Value.ToString();

                FornecedoresBusiness business = new FornecedoresBusiness();
                business.ApagarFornecedores(dto);

                MessageBox.Show("Fornecedor excluido com sucesso.");

                Listar();
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        private void btnAtuaizar_Click(object sender, EventArgs e)
        {
            FornecedoresDTO dto = new FornecedoresDTO();
            dto.Nome = txtNome.Text;
            dto.Telefone_um = txtTelefone.Text;
            dto.Cnpj = txtCnpj.Text;
            dto.Fornecimento = txtFornecimento.Text;
            dto.Telefone_dois = txtTelefoneDois.Text;
            dto.TipoProduto = txtTipoFornecimento.Text;

            FornecedoresBusiness business = new FornecedoresBusiness();
            string cnpj = lblCnpj.Text;
            business.Atualizar(dto,cnpj);

            MessageBox.Show("Fornecedor atualizado com sucesso.");
            Listar();
        }
    }
}
