﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.FinalizarCompra
{
    class FinalizarCompraDatabase
    {
        public int SalvarComBandeira(FinalizarCompraDTO dto)
        {
            string script = @"INSERT INTO venda(`valorVenda`,`Bandeira`,`Pedido_idPedido`,`FormaPagamento_idFormaPagamento`,`dataVenda`) VALUES(@valorVenda,@Bandeira,@Pedido_idPedido,@FormaPagamento_idFormaPagamento,NOW())";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("valorVenda", float.Parse(dto.ValorFinal)));
            parms.Add(new MySqlParameter("Bandeira", dto.Bandeira));
            parms.Add(new MySqlParameter("Pedido_idPedido", dto.IdPedido));
            parms.Add(new MySqlParameter("FormaPagamento_idFormaPagamento", dto.FormaPagamento));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }

        public int SalvarSemBandeira(FinalizarCompraDTO dto)
        {
            string script = @"INSERT INTO venda(`valorVenda`,`Pedido_idPedido`,`FormaPagamento_idFormaPagamento`,`dataVenda`) VALUES(@valorVenda,@Pedido_idPedido,@FormaPagamento_idFormaPagamento,NOW())";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("valorVenda", dto.ValorFinal));
            parms.Add(new MySqlParameter("Pedido_idPedido", dto.IdPedido));
            parms.Add(new MySqlParameter("FormaPagamento_idFormaPagamento", dto.FormaPagamento));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }

        public List<FinalizarCompraDTO> Listar(string idCompra)
        {
            string script = "SELECT i.`idItensPedidos` AS id, p.`nome` AS nome,i.`qtdeProduto` AS qtde,i.`valorItem` AS preco FROM `itenspedido` AS i INNER JOIN produto AS p WHERE i.`pedido` = '" + idCompra + "' AND p.`idProduto` = i.`Produto_IdProduto`";
            
            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinalizarCompraDTO> lista = new List<FinalizarCompraDTO>();

            while (reader.Read())
            {
                FinalizarCompraDTO dto = new FinalizarCompraDTO();
                dto.Id = reader.GetString("id");
                dto.Item = reader.GetString("nome");
                dto.ItemPreco = reader.GetString("preco");
                dto.ItemQuantidade = reader.GetString("qtde");
                
                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }

        public string ListarPedido()
        {
            string script = "SELECT MAX(`idPedido`) AS id FROM pedido";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinalizarCompraDTO> listar = new List<FinalizarCompraDTO>();

            string idPedido = "";

            while (reader.Read())
            {
                FinalizarCompraDTO dto = new FinalizarCompraDTO();
                dto.IdPedido = reader.GetString("id");

                idPedido = dto.IdPedido;
            }
            reader.Close();

            return idPedido;
        }

        public string ValorFinal(string idCompra)
        {
            string script = "SELECT SUM(`valorItem`) AS soma FROM `itenspedido` WHERE `pedido` = '" + idCompra + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinalizarCompraDTO> listar = new List<FinalizarCompraDTO>();

            string valFinal = "";

            while (reader.Read())
            {
                FinalizarCompraDTO dto = new FinalizarCompraDTO();
                dto.ValorFinal = reader.GetString("soma");

                valFinal = dto.ValorFinal;
            }
            reader.Close();

            return valFinal;
        }

        public int Excluir(string id)
        {
            string script = @"DELETE FROM itenspedido WHERE `idItensPedidos` = " + id;

            List<MySqlParameter> parms = new List<MySqlParameter>();
            
            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }

        public int Editar(FinalizarCompraDTO dto)
        {
            string script = @"UPDATE `itenspedido` SET `qtdeProduto` = '"+dto.ItemQuantidade+"', `valorItem` = '"+dto.ItemPreco+"' WHERE `idItensPedidos` = '"+dto.Id+"';";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            
            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }

        public string InfoCliente(string campo, string tellCliente)
        {
            string script = "SELECT `"+campo+"` AS campo FROM cliente WHERE `telefone` ='" + tellCliente + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinalizarCompraDTO> listar = new List<FinalizarCompraDTO>();

            string info = "";

            while (reader.Read())
            {
                FinalizarCompraDTO dto = new FinalizarCompraDTO();
                dto.IdPedido = reader.GetString("campo");

                info = dto.IdPedido;
            }
            reader.Close();

            return info;
        }

        public string EnderecoCliente(string idEndereco)
        {
            string script = "SELECT CONCAT(`Bairro`,' - ',`Rua`,' - ',`numero`) campo FROM `endereco` WHERE `idEndereco` ='" + idEndereco + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<FinalizarCompraDTO> listar = new List<FinalizarCompraDTO>();

            string info = "";

            while (reader.Read())
            {
                FinalizarCompraDTO dto = new FinalizarCompraDTO();
                dto.IdPedido = reader.GetString("campo");

                info = dto.IdPedido;
            }
            reader.Close();

            return info;
        }
    }
}
