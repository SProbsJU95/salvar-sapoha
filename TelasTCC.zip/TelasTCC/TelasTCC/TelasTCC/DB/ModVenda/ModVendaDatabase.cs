﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.ModVenda
{
    class ModVendaDatabase
    {
        public string ListarTelefone(string item)
        {
            string script = "select `Telefone` AS item from cliente where `Telefone` = '" + item + "';";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<ModVendasDTO> listaSenha = new List<ModVendasDTO>();

            string tell = "";

            while (reader.Read())
            {
                ModVendasDTO dto = new ModVendasDTO();
                try
                {
                    dto.TellCliente = reader.GetString("item");
                    tell = dto.TellCliente;
                }
                catch (Exception)
                {
                    tell = string.Empty;
                }

            }
            reader.Close();
            if (tell == string.Empty){tell = "Telefone não encontrado.";}
            
            return tell;
        }
    }
}
