﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Pizzaria
{
    class PizzariaBusiness
    {
        public int Salvar(PizzariaDTO dto)
        {
            /*if (dto.Produto == string.Empty)
                throw new ArgumentException("Bebida é obrigatório.");

            if (dto.QuantidadeProduto == string.Empty)
                throw new ArgumentException("Quantidade é obrigatória.");*/

            PizzariaDatabase db = new PizzariaDatabase();
            return db.Salvar(dto);
        }

        public DataTable Listar(string tipo)
        {
            PizzariaDatabase db = new PizzariaDatabase();
            return db.Listar(tipo);
        }

        public int SalvarPedido(PizzariaDTO dto)
        {
            PizzariaDatabase db = new PizzariaDatabase();
            return db.FinalizarPedido(dto);// arrumar o return
        }

        public int SalvarMeia(PizzariaDTO dto)
        {
            /*if (dto.Produto == string.Empty)
                throw new ArgumentException("Bebida é obrigatório.");

            if (dto.QuantidadeProduto == string.Empty)
                throw new ArgumentException("Quantidade é obrigatória.");*/

            PizzariaDatabase db = new PizzariaDatabase();
            return db.SalvarMeia(dto);
        }
    }
}
